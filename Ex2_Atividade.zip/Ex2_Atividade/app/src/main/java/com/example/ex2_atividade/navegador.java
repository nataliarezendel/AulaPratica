package com.example.ex2_atividade;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class navegador extends AppCompatActivity {

    private Button botaoURL;
    private EditText textoURL;
    private WebView navegadorWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegador);

        botaoURL = (Button) findViewById(R.id.botaoURL);
        textoURL = (EditText) findViewById(R.id.textoURL);
        navegadorWeb = (WebView) findViewById(R.id.navegadorWeb);

        botaoURL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegadorWeb.loadUrl(textoURL.getText().toString());
            }
        });

    }
}
