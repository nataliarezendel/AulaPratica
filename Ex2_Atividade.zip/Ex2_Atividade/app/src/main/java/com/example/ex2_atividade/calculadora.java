package com.example.ex2_atividade;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class calculadora extends AppCompatActivity {

    EditText num1, num2, resultado;
    Button soma, subtracao, divisao, multiplicacao, porcentagem;

    double n1, n2, operacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);
        num1 = (EditText) findViewById(R.id.num1);
        num2 = (EditText) findViewById(R.id.num2);
        resultado = (EditText) findViewById(R.id.resultado);

        soma = (Button) findViewById(R.id.soma);
        subtracao = (Button) findViewById(R.id.subtracao);
        divisao = (Button) findViewById(R.id.divisao);
        multiplicacao = (Button) findViewById(R.id.multiplicacao);
        porcentagem = (Button) findViewById(R.id.porcentagem);

        soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                operacao = n1+n2;
                resultado.setText(String.valueOf(operacao));
            }
        });
        subtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                operacao = n1-n2;
                resultado.setText(String.valueOf(operacao));
            }
        });

        multiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                operacao = n1*n2;
                resultado.setText(String.valueOf(operacao));
            }
        });

        divisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                operacao = n1/n2;
                resultado.setText(String.valueOf(operacao));
            }
        });
        porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                operacao = (n1*n2)/100;
                resultado.setText(String.valueOf(operacao));
            }
        });
    }


}
